#!/usr/bin/env python
# -*- coding: utf-8 -*-

import urllib,urllib2,os,re,sys
from shutil import move

offline = 'offline_dATA.xml'

def offline_parser():
    
    f = open(offline,"w+")
    
    NOM_list = []
    SIZE_list = []
    THUMB_list = []
    CATZZ_list = []
    SECC_list = []
    
    direc = 'http://www.brazzers.com/videos/all-sites/all-pornstars/all-categories/thisyear/bydate/'
    page = 1
    

    
    while page <= 50:
        url= direc + str(page)
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="/scenes/view/(.+?)"\n               title="(.+?)">\n                <img src="(.+?)"\n').findall(link)
        for id, name, thumb in match:
            url = "http://www.brazzers.com/scenes/view/" + id
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            match=re.compile('<li>SD MP4 <span>(.+?)</span>').findall(link)
            #match=re.compile('<li>HD MP4 720P <span>(.+?)</span>').findall(link)
            repl = str(match).replace("['[","")
            size = repl.replace(" MB]']", "")
            #size = repl.replace(" GiB]']", "")
            block = re.split(r'<div class=', link)
            catzz = re.findall('data-trackid="BZ:TOUR:RELEASE:LINK tag-name"\n                               title="(.+?)">', block[35])
            secc = re.compile('"BZ:TOUR:RELEASE:LINK niche-site"\n                       title="(.+?)"></a>').findall(block[34])
            
            if size != "" and size != "[]":
                
                print "ADDING"
                NOM_list.append(name)
                SIZE_list.append(size)
                THUMB_list.append(thumb)
                CATZZ_list.append(str(catzz))
                SECC_list.append(secc[0])
                    
            else:
                print "PASSING"
                pass
            

            
        page += 1
        print page        
        
    
    i = 0    
    
    while i < int(len(NOM_list)):
        f.write(SIZE_list[i] +"\n")
        f.write("<item>\n")
        f.write("<name>" +NOM_list[i] +"</name>\n")
        f.write("<thumb>" +THUMB_list[i] +"</thumb>\n")
        f.write("<size>" +SIZE_list[i] +"</size>\n")
        f.write("<tags>" +CATZZ_list[i] +"</tags>\n")
        f.write("<secc>" +SECC_list[i] +"</secc>\n")
        f.write("</item>\n")
        f.write("\n")
        f.write("\n")
        
        i +=1
        
    f.close()

offline_parser()
