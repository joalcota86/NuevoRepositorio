#!/usr/bin/env python
# -*- coding: utf-8 -*-

import urllib,urllib2,os,re,sys
import xbmcaddon,xbmcplugin,xbmcgui
import dataparser,verifier
import time,datetime
from shutil import move


ts = time.time()
st = datetime.datetime.fromtimestamp(ts).strftime('%Y%m%d')


Config = xbmcaddon.Addon()

dialog = xbmcgui.Dialog()

Progress = xbmcgui.DialogProgress()

 
# path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'))


timestamp = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.zz/resources/tools', 'timestamp.txt'))

pw = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.zz/resources/tools', 'pw.txt'))


file = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.zz/resources/database', 'source.xml'))

file2 = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.zz/resources/database', 'source_add.xml'))

output = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.zz/resources/database', 'output.xml'))

offline = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.zz/resources/database', 'offline_db.xml'))

offline2 = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.zz/resources/database', 'offline_add.xml'))



filenames = file2, file

off_filenames = offline2, offline




def offline_parser(): # "" and [] 
    
    f = open(offline,"w+")
    
    NOM_list = []
    SIZE_list = []
    THUMB_list = []
    
    direc = 'http://www.brazzers.com/videos/all-sites/all-pornstars/all-categories/thisyear/bydate/'
    page = 1
    
    Progress.create("Actualizando..", "Descargando datos de página...")
    Progress.update(0)
    if Progress.iscanceled() == True:
        sys.exit()
    
    while page <= 50:
        url= direc + str(page)
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="/scenes/view/(.+?)"\n               title="(.+?)">\n                <img src="(.+?)"\n').findall(link)
        for id, name, thumb in match:
            url = "http://www.brazzers.com/scenes/view/" + id
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            match=re.compile('<li>SD MP4 <span>(.+?)</span>').findall(link)
            #match=re.compile('<li>HD MP4 720P <span>(.+?)</span>').findall(link)
            repl = str(match).replace("['[","")
            size = repl.replace(" MB]']", "")
            #size = repl.replace(" GiB]']", "")
            if size != "" and size != "[]":
            
                NOM_list.append(name)
                SIZE_list.append(size)
                THUMB_list.append(thumb)
                    
            else: pass
            
            
            if (len(NOM_list)) == 60:
                Progress.update(10)
            elif (len(NOM_list)) == 120:
                Progress.update(20)
            elif (len(NOM_list)) == 180:
                Progress.update(30)
            elif (len(NOM_list)) == 240:
                Progress.update(50)
            elif (len(NOM_list)) == 300:
                Progress.update(60)
            elif (len(NOM_list)) == 360:
                Progress.update(70)
            elif (len(NOM_list)) == 420:
                Progress.update(80)
            elif (len(NOM_list)) == 480:
                Progress.update(90)
            elif (len(NOM_list)) == 540:
                Progress.update(95)

            
        page += 1        
        
    
    i = 0    
    
    while i < int(len(NOM_list)):
        f.write(SIZE_list[i] +"\n")
        f.write("<item>\n")
        f.write("<name>" +NOM_list[i] +"</name>\n")
        f.write("<thumb>" +THUMB_list[i] +"</thumb>\n")
        f.write("<size>" +SIZE_list[i] +"</size>\n")
        f.write("</item>\n")
        f.write("\n")
        f.write("\n")
        
        i +=1
        
    f.close()




def offline_update():
    
    f = open(offline2,"w+")
    
    NOM_list = []
    SIZE_list = []
    THUMB_list = []
    
    direc = 'http://www.brazzers.com/videos/all-sites/all-pornstars/all-categories/thisyear/bydate/'
    page = 1
    
    while page <= 23:
        url= direc + str(page)
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="/scenes/view/(.+?)"\n               title="(.+?)">\n                <img src="(.+?)"\n').findall(link)
        i = 0
        for id, name, thumb in match:
            url = "http://www.brazzers.com/scenes/view/" + id
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            match=re.compile('<li>SD MP4 <span>(.+?)</span>').findall(link)
            #match=re.compile('<li>HD MP4 720P <span>(.+?)</span>').findall(link)
            repl = str(match).replace("['[","")
            size = repl.replace(" MB]']", "")
            #size = repl.replace(" GiB]']", "")
            if size != "" and size != "[]":
                NOM_list.append(name)
                SIZE_list.append(size)
                THUMB_list.append(thumb)
                
                with open(offline) as sf:
                    last = sf.readline()
    
                    if size in last:
                        content = ''
                        for f in off_filenames:
                            content = content + open(f).read()
                            open(output,'wb').write(content)
                        move(output,offline)
                        # open(timestamp,'w+').write(st)
                        dialog.ok('Actualizado', '                         DATOS DE LA WEB: "actualizados"', '', '                                       Ya puede utilizar ZZ!!')
                        sys.exit()
                    else:
                        f.write(SIZE_list[i] +"\n")
                        f.write("<item>\n")
                        f.write("<name>" +NOM_list[i] +"</name>\n")
                        f.write("<thumb>" +THUMB_list[i] +"</thumb>\n")
                        f.write("<size>" +SIZE_list[i] +"</size>\n")
                        f.write("</item>\n")
                        f.write("\n")
                        f.write("\n")
                        i += 1
            else: pass
        page += 1        
        
    
    i = 0    
    
    while i < int(len(NOM_list)):
        
        f.write("<item>\n")
        f.write("<name>" +NOM_list[i] +"</name>\n")
        f.write("<thumb>" +THUMB_list[i] +"</thumb>\n")
        f.write("<size>" +SIZE_list[i] +"</size>\n")
        f.write("</item>\n")
        f.write("\n")
        f.write("\n")
        
        i +=1
        
    f.close()




def offline_reader():
    
    opciones = open(offline, "r+")
    contenido = opciones.read()
    
    NOM_list = []
    SIZE_list = []
    THUMB_list = []
    
    matches = dataparser.etiqueta_maestra(contenido, "<item>(.*?)</item>")
    for item in matches:
        NAME = dataparser.subetiqueta(item, "<name>(.*?)</name>")
        THUMB = dataparser.subetiqueta(item, "<thumb>(.*?)</thumb>")
        SIZE = dataparser.subetiqueta(item, "<size>(.*?)</size>")
        
        NOM_list.append(NAME)
        SIZE_list.append(SIZE)
        THUMB_list.append(THUMB)
    
    i = 0
    j = 1
    
    nvid = 0
    
    Progress.create("Procesando..")
    if Progress.iscanceled() == True:
        sys.exit()
        
    if Config.getSetting("vidslim") == '0':
        vidslim = 2999
    elif Config.getSetting("vidslim") == '1':
        vidslim = 14
    elif Config.getSetting("vidslim") == '2':
        vidslim = 29
    elif Config.getSetting("vidslim") == '3':
        vidslim = 49
    elif Config.getSetting("vidslim") == '4':
        vidslim = 99
    
    
    while i < int(len(NOM_list)) and j <= vidslim:
        
        searchfile = open(file)
    
        for line in searchfile:
            if SIZE_list[i] in line:
                rawtitle = re.compile('<title>(.+?)</title>').findall(line)
                cleantitle = str(rawtitle[0]).replace("&#039;", "'")
                title_sc = str(cleantitle).replace("&#39;", "'")
                rawid = re.compile('<id>(.+?)</id>').findall(line)
                id = str(rawid[0])
                match = re.compile('<url>(.+?)</url>').findall(line)
                nommatch = NOM_list[i].split(" ")
                if len(str(nommatch[0])) < 4:
                    matchtitle = str(nommatch[1])
                else:
                    matchtitle = str(nommatch[0])
                           
                    
                if matchtitle.lower() in title_sc.lower():
                    print matchtitle.lower()
                    print title_sc.lower()
                        
                    
                    if Config.getSetting("engine") == '1':
                        torrent = "plugin://plugin.video.pulsar/play?uri=" + str(match[0])
                    else:
                        torrent = "plugin://plugin.video.xbmctorrent/play/" + str(match[0])
                    
                    
                    if Config.getSetting("seedscheck") == 'true':
                        Progress.update(0, "Comprobando número de Seeds...")
                        if Config.getSetting("seedsmin") == '0':
                            seedsmin = 1
                        elif Config.getSetting("seedsmin") == '1':
                            seedsmin = 20
                        elif Config.getSetting("seedsmin") == '2':
                            seedsmin = 30
                        elif Config.getSetting("seedsmin") == '3':
                            seedsmin = 50

                                               
                        try:
                            
                            url = "http://kasto.come.in/usearch/" + urllib.quote_plus(title_sc.encode("utf-8")) + "user:chkm8te/"

                            req = urllib2.Request(url)
                            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                            response = urllib2.urlopen(req)
                            link=response.read()
                            response.close()
                            match=re.compile('<span id="' + id + '"><strong><a href=".+?">.+?</a> > <a href=".+?">.+?</a></strong></span>                \t                </span>\n            \t            </div>\n            </td>\n\t\t\t\t\t\t\t\t\t<td class="nobr center">.+?<span>MB</span></td>\n\t\t\t<td class="center">1</td>\n\t\t\t<td class="center">.+?</td>\n\t\t\t<td class="green center">(.+)</td>').findall(link)
                            print match[0]
                            seeds = match[0]
                            
                            if int(seeds) >= 120:
                                title = "[COLOR darkblue][" + str(seeds) + "] [COLOR chartreuse]" + NOM_list[i] + "[/COLOR]"
                                addLink(title,torrent,THUMB_list[i])
                                print "ADDED"
                                nvid += 1
                                j +=1
                            elif int(seeds) >= 70 and int(seeds) < 120:
                                title = "[COLOR darkblue][" + str(seeds) + "] [COLOR yellow]" + NOM_list[i] + "[/COLOR]"
                                addLink(title,torrent,THUMB_list[i])
                                print "ADDED"
                                nvid += 1
                                j +=1                           
                            elif int(seeds) >= seedsmin and int(seeds) < 70:
                                title = "[COLOR darkblue][" + str(seeds) + "] [COLOR red]" + NOM_list[i] + "[/COLOR]"
                                addLink(title,torrent,THUMB_list[i])
                                print "ADDED"
                                nvid += 1
                                j +=1
                            else:
                                Progress.update(100, "", "", "[COLOR red][LOW][/COLOR]")
                                print "LOW"
                                pass
                            
                            
                            
                            Progress.update(100, "", "", str(nvid))
                            
                            
                        except:
                            print "PASSED " + urllib.quote_plus(title_sc.encode("utf-8"))
                            Progress.update(100, "", "", "passing...")
                            pass
                    else:
                        Progress.update(0, "Agregando vídeos...")
                        addLink(NOM_list[i],torrent,THUMB_list[i])
                        Progress.update(100, "", "", str(int(nvid) + 1))
                        nvid += 1
                        
            else: pass
        
        i +=1
        
    searchfile.close()



######################  ONLINE  #######################



def xxx_parser(filter,day,sort,pages):
    
    NOM_list = []
    SIZE_list = []
    THUMB_list = []
    
    direc = 'http://www.brazzers.com/videos/all-sites/all-pornstars/' +str(filter) +str(day) +str(sort) +'/'
    print direc
    page = 1
    
    Progress.create("Actualizando..", "Analizando datos...")
    Progress.update(0)
    if Progress.iscanceled() == True:
        sys.exit()

    progress = 0
    uno = 100 / (12 * float(pages))

    while page <= int(pages):
        url= direc + str(page)
        print url
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="/scenes/view/(.+?)"\n               title="(.+?)">\n                <img src="(.+?)"\n').findall(link)
            
        for id, name, thumb in match:
            percent = int(progress)
            message = "Página " + str(page) + " de " + str(pages)
            Progress.update(int(percent), "Descargando datos de página...", "", message )
            xbmc.sleep( 1000 )
            if Progress.iscanceled():
                break
            url = "http://www.brazzers.com/scenes/view/" + id
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            match=re.compile('<li>SD MP4 <span>(.+?)</span>').findall(link)
            #match=re.compile('<li>HD MP4 720P <span>(.+?)</span>').findall(link)
            repl = str(match).replace("['[","")
            size = repl.replace(" MB]']", "")
            #size = repl.replace(" GiB]']", "")
            NOM_list.append(name)
            print NOM_list
            SIZE_list.append(size)
            print SIZE_list
            THUMB_list.append(thumb)
            print THUMB_list
            
            progress = progress + uno
            

            
        page += 1        
        
    i = 0
    j = 1
    
    
    
    while i < int(len(NOM_list)): # and j <=14:
        """
        if j == 14:
            Progress.update(100)
        """
        searchfile = open(file)
        for line in searchfile:
            if SIZE_list[i] in line:
                rawtitle = re.compile('<title>(.+?)</title>').findall(line)
                cleantitle = str(rawtitle[0]).replace("&#039;", "'")
                title_sc = str(cleantitle).replace("&#39;", "'")
                rawid = re.compile('<id>(.+?)</id>').findall(line)
                id = str(rawid[0])
                match = re.compile('<url>(.+?)</url>').findall(line)
                nommatch = NOM_list[i].split(" ")
                if len(str(nommatch[0])) < 4:
                    matchtitle = str(nommatch[1])
                else:
                    matchtitle = str(nommatch[0])
                           
                    
                if matchtitle.lower() in title_sc.lower():
                    print matchtitle.lower()
                    print title_sc.lower()
                    
                    # j +=1    
                    
                    if Config.getSetting("engine") == '1':
                        torrent = "plugin://plugin.video.pulsar/play?uri=" + str(match[0])
                    else:
                        torrent = "plugin://plugin.video.xbmctorrent/play/" + str(match[0])
                    
                    """
                    if int(seeds) >= 100:
                        title = "[COLOR chartreuse]" + NOM_list[i] + "[/COLOR]"
                    elif int(seeds) >= 50 and int(seeds) < 100:
                        title = "[COLOR yellow]" + NOM_list[i] + "[/COLOR]"
                    else:
                        title = "[COLOR red]" + NOM_list[i] + "[/COLOR]"
                    """
                    
                    addLink(NOM_list[i],torrent,THUMB_list[i])
                    print "ADDED"
            else: pass
        searchfile.close()
        
        i +=1
        


######################  SOURCE  ####################### 



def source_update():
    
    f = open(file2,"w+")
    
    try:
        direc = "http://kasto.come.in/usearch/category%3Axxx%20user%3Achkm8te%20seeds%3A2%20files%3A1/"
  
        page = 1
    
        sort = "/?field=time_add&sorder=desc"
        
        direc_var = direc + str(page) + sort
        
        response = urllib2.urlopen(direc_var)
        link = response.read()
        response.close()
        match = re.compile('class="turnoverButton siteButton bigButton">5</a><a class="blank turnoverButton siteButton nohov"><span></span></a><a rel="nofollow" href=".+?" class="turnoverButton siteButton bigButton">(.+?)</a>').findall(link)
        print "THIS " + str(match[0])

        maxpage = str(match[0])
        
        while page <= maxpage:
            print maxpage
              
            direc_var = direc + str(page) + sort
            response = urllib2.urlopen(direc_var)
            link = response.read()
            response.close()
            # match = re.compile('<a title="Torrent magnet link" href="(.+?)" class=".+?"><span></span></a>\n                <a title="Download torrent file" href=".+?" class=".+?"><span></span></a>\n            </div>\n            <div class=".+?">\n                <a href=".+?" class=".+?"></a>\n                <a href=".+?" class=".+?"></a>\n            <div class=".+?">\n\n                <a href=".+?" class=".+?">(.+?)</a>\n\n                                                <span class=".+?">\n                                Posted by <a class=".+?" href=".+?">.+?</a>&nbsp;<img src=".+?" alt=".+?"/>  in <span id="(.+?)"><strong><a href=".+?">.+?</a> > <a href=".+?">.+?</a></strong></span>                \t                </span>\n            \t            </div>\n            </td>\n\t\t\t\t\t\t\t\t\t<td class=".+?">(.+?) <span>MB</span></td>').findall(link)        
            # match = re.compile('<a title="Torrent magnet link" href="(.+?)" class=".+?"><span></span></a>\n                <a title="Download torrent file" href=".+?" class=".+?"><span></span></a>\n            </div>\n            <div class=".+?">\n                <a href=".+?" class=".+?"></a>\n                <a href=".+?" class=".+?"></a>\n            <div class=".+?">\n\n                <a href=".+?" class=".+?">(.+?)</a>\n\n                                                <span class=".+?">\n                                Posted by <a class=".+?" href=".+?">.+?</a> in <span id="(.+?)"><strong><a href=".+?">.+?</a> > <a href=".+?">.+?</a></strong></span>                \t                </span>\n            \t            </div>\n            </td>\n\t\t\t\t\t\t\t\t\t<td class=".+?">(.+?) <span>MB</span></td>\n\t\t\t<td class=".+?">.+?</td>\n\t\t\t<td class=".+?">.+?</td>\n\t\t\t<td class="green center">(.+?)</td>').findall(link)
            match = re.compile('<a title="Torrent magnet link" href="(.+?)" class=".+?"><i class=".+?"></i></a>\n                <a title="Download torrent file" href=".+?" class=".+?"><i class=".+?"></i></a>\n            </div>\n            <div class=".+?">\n                <a href=".+?" class=".+?"></a>\n                <a href=".+?" class=".+?"></a>\n            <div class=".+?">\n\n                <a href=".+?" class=".+?">(.+?)</a>\n\n                                                <span class=".+?">\n                                Posted by <a class=".+?" href=".+?">.+?</a> in <span id="(.+?)"><strong><a href=".+?">.+?</a> > <a href=".+?">.+?</a></strong></span>                \t                </span>\n            \t            </div>\n            </td>\n\t\t\t\t\t\t\t\t\t<td class=".+?">(.+?) <span>MB</span></td>\n\t\t\t<td class=".+?">.+?</td>\n\t\t\t<td class=".+?">.+?</td>\n\t\t\t<td class="green center">(.+?)</td>').findall(link)
    
            
            # print match
            with open(file) as sf:
                last = sf.readline()
           
                for url,name,id,size,seeds in match:
    
                    if id in last:
                        content = ''
                        for f in filenames:
                            content = content + open(f).read()
                            open(output,'wb').write(content)
                        move(output,file)
                        open(timestamp,'w+').write(st)
                        dialog.ok('Actualizado', '                           BASE DE DATOS: "actualizada"', '', '  Vuelva a entrar al add-on para completar la actualización.')
                        sys.exit()
                    else:
                        if len(str(size)) == 5:
                            size = str(size) + "0"
                        else:
                            size = str(size)
                        f.write(id +"\n")
                        # f.write(">> Page " +str(page) +" of " +str(maxpage) +"\n")
                        f.write("\n")
                        f.write("<item>\n")
                        f.write(size +"<title>" +str(name) +"</title>")
                        f.write("<url>" +urllib.quote_plus(url.encode("utf-8")) +"</url>")
                        f.write("<id>" +str(id) +"</id>\n")
                        f.write("</item>\n")
                        f.write("\n")
                        f.write("\n")
    
            page += 1
        f.close()

    
    except:
        try:
            
            web = verifier.verify()

            print "ESTA: " + web
            
            direc = web + "usearch/category%3Axxx%20user%3Achkm8te%20seeds%3A2%20files%3A1/"
      
            page = 1
        
            sort = "/?field=time_add&sorder=desc"
            
            direc_var = direc + str(page) + sort
            
            response = urllib2.urlopen(direc_var)
            link = response.read()
            response.close()
            match = re.compile('class="turnoverButton siteButton bigButton">5</a><a class="blank turnoverButton siteButton nohov"><span></span></a><a rel="nofollow" href=".+?" class="turnoverButton siteButton bigButton">(.+?)</a>').findall(link)
            print "THIS " + str(match[0])
    
            maxpage = str(match[0])
            
            while page <= maxpage:
                print maxpage
                  
                direc_var = direc + str(page) + sort
                response = urllib2.urlopen(direc_var)
                link = response.read()
                response.close()
                match = re.compile('<a title="Torrent magnet link" href="(.+?)" class=".+?"><i class=".+?"></i></a>\n<a title="Download torrent file" href=".+?" class=".+?"><i class=".+?"></i></a>\n</div>\n<div class=".+?">\n<a href=".+?" class=".+?"></a>\n<a href=".+?" class=".+?"></a>\n<div class=".+?">\n<a href=".+?" class=".+?">(.+?)</a>\n<span class=".+?">\nPosted by <a class="plain" href="/user/chkm8te/">chkm8te</a> in <span id="(.+?)"><strong><a href="/xxx/">XXX</a> > <a href="/xxx-video/">Video</a></strong></span> </span>\n</div>\n</td>\n<td class=".+?">(.+?) <span>MB</span></td>\n<td class=".+?">.+?</td>\n<td class=".+?">.+?</td>\n<td class="green center">(.+?)</td>\n').findall(link)
                with open(file) as sf:
                    last = sf.readline()
               
                    for url,name,id,size,seeds in match:
        
                        if id in last:
                            content = ''
                            for f in filenames:
                                content = content + open(f).read()
                                open(output,'wb').write(content)
                            move(output,file)
                            open(timestamp,'w+').write(st)
                            dialog.ok('Actualizado', '                           BASE DE DATOS: "actualizada"', '', '  Vuelva a entrar al add-on para completar la actualización.')
                            sys.exit()
                        else:
                            if len(str(size)) == 5:
                                size = str(size) + "0"
                            else:
                                size = str(size)
                            f.write(id +"\n")
                            # f.write(">> Page " +str(page) +" of " +str(maxpage) +"\n")
                            f.write("\n")
                            f.write("<item>\n")
                            f.write(size +"<title>" +str(name) +"</title>")
                            f.write("<url>" +urllib.quote_plus(url.encode("utf-8")) +"</url>")
                            f.write("<id>" +str(id) +"</id>\n")
                            f.write("</item>\n")
                            f.write("\n")
                            f.write("\n")
        
                page += 1
            f.close()
            
        except: pass

    


def ka_source_file():
    
    # "http://unlocktorrent.com/"
    
    f = open(file,"w+")
    
    # direc = "http://kickass.filesoup.com/usearch/category%3Axxx%20user%3Achkm8te%20seeds%3A2%20files%3A1/"
    
    

    direc = "http://kasto.come.in/usearch/category%3Axxx%20user%3Achkm8te%20seeds%3A2%20files%3A1/"
    
    
    page = 1

    sort = "/?field=time_add&sorder=desc"
    
    Progress.create("Actualizando..", "Descargando base de datos completa...")
    Progress.update(0)
    if Progress.iscanceled() == True:
        sys.exit()
    
    direc_var = direc + str(page) + sort
    response = urllib2.urlopen(direc_var)
    link = response.read()
    response.close()
    match = re.compile('class="turnoverButton siteButton bigButton">5</a><a class="blank turnoverButton siteButton nohov"><span></span></a><a rel="nofollow" href=".+?" class="turnoverButton siteButton bigButton">(.+?)</a>').findall(link)
    print match[0]
    maxpage = match[0]
    i = 1
    while page <= int(maxpage):
        
        if i <= int(maxpage):
            percent = (float(i) / int(maxpage)) * 100
            message = "Página " + str(i) + " de " + str(maxpage)
            Progress.update(int(percent), "", "", message )
            xbmc.sleep( 1000 )
            if Progress.iscanceled():
                break
            i = i + 1
          
            direc_var = direc + str(page) + sort
            response = urllib2.urlopen(direc_var)
            link = response.read()
            response.close()
            # match = re.compile('<a title="Torrent magnet link" href="(.+?)" class=".+?"><span></span></a>\n                <a title="Download torrent file" href=".+?" class=".+?"><span></span></a>\n            </div>\n            <div class=".+?">\n                <a href=".+?" class=".+?"></a>\n                <a href=".+?" class=".+?"></a>\n            <div class=".+?">\n\n                <a href=".+?" class=".+?">(.+?)</a>\n\n                                                <span class=".+?">\n                                Posted by <a class=".+?" href=".+?">.+?</a>&nbsp;<img src=".+?" alt=".+?"/>  in <span id="(.+?)"><strong><a href=".+?">.+?</a> > <a href=".+?">.+?</a></strong></span>                \t                </span>\n            \t            </div>\n            </td>\n\t\t\t\t\t\t\t\t\t<td class=".+?">(.+?) <span>MB</span></td>').findall(link)        
            # match = re.compile('<a title="Torrent magnet link" href="(.+?)" class=".+?"><span></span></a>\n                <a title="Download torrent file" href=".+?" class=".+?"><span></span></a>\n            </div>\n            <div class=".+?">\n                <a href=".+?" class=".+?"></a>\n                <a href=".+?" class=".+?"></a>\n            <div class=".+?">\n\n                <a href=".+?" class=".+?">(.+?)</a>\n\n                                                <span class=".+?">\n                                Posted by <a class=".+?" href=".+?">.+?</a> in <span id="(.+?)"><strong><a href=".+?">.+?</a> > <a href=".+?">.+?</a></strong></span>                \t                </span>\n            \t            </div>\n            </td>\n\t\t\t\t\t\t\t\t\t<td class=".+?">(.+?) <span>MB</span></td>\n\t\t\t<td class=".+?">.+?</td>\n\t\t\t<td class=".+?">.+?</td>\n\t\t\t<td class="green center">(.+?)</td>').findall(link)
            match = re.compile('<a title="Torrent magnet link" href="(.+?)" class=".+?"><i class=".+?"></i></a>\n                <a title="Download torrent file" href=".+?" class=".+?"><i class=".+?"></i></a>\n            </div>\n            <div class=".+?">\n                <a href=".+?" class=".+?"></a>\n                <a href=".+?" class=".+?"></a>\n            <div class=".+?">\n\n                <a href=".+?" class=".+?">(.+?)</a>\n\n                                                <span class=".+?">\n                                Posted by <a class=".+?" href=".+?">.+?</a> in <span id="(.+?)"><strong><a href=".+?">.+?</a> > <a href=".+?">.+?</a></strong></span>                \t                </span>\n            \t            </div>\n            </td>\n\t\t\t\t\t\t\t\t\t<td class=".+?">(.+?) <span>MB</span></td>\n\t\t\t<td class=".+?">.+?</td>\n\t\t\t<td class=".+?">.+?</td>\n\t\t\t<td class="green center">(.+?)</td>').findall(link)
            for url,name,id,size,seeds in match:
                print name
                if len(str(size)) == 5:
                    size = str(size) + "0"
                else:
                    size = str(size)
                f.write(id +"\n")
                f.write(">> Page " +str(page) +" of " +str(maxpage) +"\n")
                f.write("\n")
                f.write("<item>\n")
                f.write(size +"<title>" +str(name) +"</title>")
                f.write("<url>" +urllib.quote_plus(url.encode("utf-8")) +"</url>")
                f.write("<id>" +str(id) +"</id>\n")
                f.write("</item>\n")
                f.write("\n")
                f.write("\n")
            page += 1
    f.close()



######################  RUNNER  #######################

"""

def filters():

    if Config.getSetting("anal") == 'true':
        tag1 = " anal"
    else:
        tag1 = ""

    if Config.getSetting("blonde") == 'true':
        tag2 = " blonde"
    else:
        tag2 = ""
        
    if Config.getSetting("blowjob") == 'true':
        tag3 = " blowjob"
    else:
        tag3 = ""
    
    if Config.getSetting("bondage") == 'true':
        tag4 = " bondage"
    else:
        tag4 = ""
            
    if Config.getSetting("dildo") == 'true':
        tag5 = " dildo"
    else:
        tag5 = ""

    if Config.getSetting("dbpen") == 'true':
        tag6 = " double-penetration-dp"
    else:
        tag6 = ""
    
    if Config.getSetting("ebony") == 'true':
        tag7 = " ebony"
    else:
        tag7 = ""

    if Config.getSetting("gaping") == 'true':
        tag8 = " gaping"
    else:
        tag8 = ""
        
    if Config.getSetting("hairy") == 'true':
        tag9 = " hairy-puss"
    else:
        tag9 = ""
    
    if Config.getSetting("handjob") == 'true':
        tag10 = " handjob"
    else:
        tag10 = ""
            
    if Config.getSetting("htits") == 'true':
        tag11 = " huge-tits"
    else:
        tag11 = ""

    if Config.getSetting("lesbian") == 'true':
        tag12 = " lesbian"
    else:
        tag12 = ""
    if Config.getSetting("mastur") == 'true':
        tag13 = " masturbation"
    else:
        tag13 = ""
        
    if Config.getSetting("milf") == 'true':
        tag14 = " milf"
    else:
        tag14 = ""
    
    if Config.getSetting("rimjob") == 'true':
        tag15 = " rimjob"
    else:
        tag15 = ""
            
    if Config.getSetting("squirt") == 'true':
        tag16 = " squirt"
    else:
        tag16 = ""

    if Config.getSetting("strapon") == 'true':
        tag17 = " strap-on"
    else:
        tag17 = ""
        

    filters = tag1 + tag2 + tag3 + tag4 + tag5 + tag6 + tag7 + tag8 + tag9 + tag10 + tag11 + tag12 + tag13 + tag14 + tag15 + tag16 + tag17
    whitespace = filters.strip()
    filter = whitespace.replace(' ', '%20')
    
    if filters == "":
        filter = "all-categories"
        return filter
    else:
        return filter


if Config.getSetting("enable_tags") == 'true':
    filter = filters()
else:
    filter = "all-categories"



if Config.getSetting("sort") == '0':
    sort = "bydate"
elif Config.getSetting("sort") == '1':
    sort = "mostrated"
elif Config.getSetting("sort") == '2':
    sort = "mostviewed"



if Config.getSetting("anyday") == '0':
    day = '/thismonth/'
else:
    day = '/thisyear/'
    
    
if Config.getSetting("pages") == '0':
    pages = "1"
elif Config.getSetting("pages") == '1':
    pages = "2"
elif Config.getSetting("pages") == '2':
    pages = "3"
elif Config.getSetting("pages") == '3':
    pages = "4"
elif Config.getSetting("pages") == '4':
    pages = "5"
elif Config.getSetting("pages") == '5':
    pages = "6"
elif Config.getSetting("pages") == '6':
    pages = "7"
elif Config.getSetting("pages") == '7':
    pages = "8"
"""


#if Config.getSetting("enable_online") == 'false':        
if Config.getSetting("database") == '0' and Config.getSetting("state") == 'false':
    with open(timestamp) as f:
        date = f.readline()
        if st in date:     
            pass
        else:
            Config.setSetting("state", 'true')
            source_update()
elif Config.getSetting("database") == '0' and Config.getSetting("state") == 'true':
    Config.setSetting("state", 'false')
    offline_update()


elif Config.getSetting("database") == '1':
    pass
    
    
if Config.getSetting("database") == '2' and Config.getSetting("state") == 'false' and Config.getSetting("state2") == 'false':
    Config.setSetting("state", 'true')
    source_update()
    
elif Config.getSetting("database") == '2' and Config.getSetting("state") == 'true':
    Config.setSetting("state", 'false')
    Config.setSetting("state2", 'true')
    offline_update()
    
else:
    pass
#else: pass



xbmctpath = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.xbmctorrent'))
pulsarpath = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.pulsar'))


if os.path.isdir(xbmctpath) == True and os.path.isdir(pulsarpath) == True:
    pass
elif os.path.isdir(xbmctpath) == False and os.path.isdir(pulsarpath) == False:
    dialog.ok('ERROR', '                                  Para utilizar este add-on,', '             necesita tener instalado XBMCtorrent o Pulsar.')
    sys.exit()
elif os.path.isdir(xbmctpath) == True and os.path.isdir(pulsarpath) == False:
    Config.setSetting("engine", "0")
elif os.path.isdir(xbmctpath) == False and os.path.isdir(pulsarpath) == True:
    Config.setSetting("engine", "1")





def addLink(name,url,iconimage):
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setProperty('Video', 'true')
    liz.setProperty('IsPlayable', 'true')       
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)


 
# ka_source_file()
# source_update()


# offline_parser()
# offline_update()

# xxx_parser('all-categories','/thisyear/','mostrated')

# xxx_parser(filter,day,sort,'4')



def run_addon():
    
    if os.path.isfile(pw) == False and Config.getSetting("pword") == "":
        dialog.ok('ADVERTENCIA', '               Este add-on contiene material para adultos,', '            debe configurar un "password" para continuar.', "    Ingrese 'nopass123' si no le interesa esta posibilidad.")
        kb = xbmc.Keyboard('','Ingrese el password deseado:',False)
        kb.doModal()
        if (kb.isConfirmed()):
            pword = kb.getText()
            f = open(pw,"w+")
            f.write(pword)
            f.close()
            Config.setSetting("pword", pword)
        else:
            sys.exit()
    elif os.path.isfile(pw) == False and Config.getSetting("pword") != "":
        f = open(pw,"w+")
        f.write(Config.getSetting("pword"))
        f.close()
        pass
    else: pass
    
    if Config.getSetting("enable_online") == 'true' and Config.getSetting("pword") != "nopass123" and Config.getSetting("pword") != "'nopass123'":
        kb = xbmc.Keyboard('','Ingrese su password:',True)
        kb.doModal()
        if (kb.isConfirmed()):
            pword = kb.getText()
            with open(pw) as f:
                pwread = f.readline()
                if pword in pwread and pword != "":
                    try:
                        xxx_parser(filter,day,sort,pages)
                        xbmc.executebuiltin('Container.SetViewMode(500)')
                    except:
                        dialog.ok('ERROR', '                                  La página web está caída.', '              Puede utilizar el "Modo Database" hasta que se', '                                      restituya el servicio.')
                        sys.exit()
                else:
                    dialog.ok('ERROR', '                                 Su password es incorrecto.', '        Vuelva a entrar al add-on para intentarlo nuevamente.')
                    sys.exit()
        else: sys.exit()

    elif Config.getSetting("enable_online") == 'false' and Config.getSetting("pword") != "nopass123" and Config.getSetting("pword") != "'nopass123'":
        kb = xbmc.Keyboard('','Ingrese su password:',True)
        kb.doModal()
        if (kb.isConfirmed()):
            pword = kb.getText()
            with open(pw) as f:
                pwread = f.readline()
                if pword in pwread and pword != "":
                    offline_reader()
                    xbmc.executebuiltin('Container.SetViewMode(500)')
                    Config.setSetting("state2", 'false')
                else:
                    dialog.ok('ERROR', '                                 Su password es incorrecto.', '        Vuelva a entrar al add-on para intentarlo nuevamente.')
                    sys.exit()
        else: sys.exit()
    else: run_addon_nopass()

        

def run_addon_nopass():
    
    if Config.getSetting("enable_online") == 'true':
        try:
            xxx_parser(filter,day,sort,pages)
            xbmc.executebuiltin('Container.SetViewMode(500)')
        except:
            dialog.ok('ERROR', '                                  La página web está caída.', '              Puede utilizar el "Modo Database" hasta que se', '                                      restituya el servicio.')
            sys.exit()
    else:
        offline_reader()
        xbmc.executebuiltin('Container.SetViewMode(500)')
        Config.setSetting("state2", 'false')
    


def runner():
    
    try:
        with open(pw) as f:
            pwread = f.readline()
            if "nopass123" in pwread or "'nopass123'" in pwread or Config.getSetting("pword") == "nopass123" or Config.getSetting("pword") == "'nopass123'":
                run_addon_nopass()
            else:
                run_addon()
    except:
        run_addon()


runner()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
